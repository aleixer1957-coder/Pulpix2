PULPIX 2 - base Android
Esta es una versión inicial del proyecto, con acceso Administrador/Empleado y Capital inicial.
Credenciales de prueba:
admin / 1234
empleado / 1234
Para convertir el proyecto en APK se requiere un entorno Android/Gradle con SDK instalado.
