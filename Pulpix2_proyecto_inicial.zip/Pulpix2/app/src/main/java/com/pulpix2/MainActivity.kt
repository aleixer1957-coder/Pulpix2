package com.pulpix2

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.view.*
import android.widget.*
import android.content.Context

class MainActivity : Activity() {
    lateinit var prefs: android.content.SharedPreferences
    fun tv(s:String, size:Float=18f)=TextView(this).apply{ text=s; textSize=size; setPadding(24,18,24,18) }
    override fun onCreate(b:Bundle?) { super.onCreate(b); prefs=getSharedPreferences("pulpix",0); login() }
    fun login(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL; setPadding(32,70,32,20)}
        box.addView(tv("🍓 PULPIX 2",30f)); box.addView(tv("Acceso",22f))
        val u=EditText(this); u.hint="Usuario"; box.addView(u)
        val p=EditText(this); p.hint="Contraseña"; p.inputType=129; box.addView(p)
        val btn=Button(this); btn.text="INGRESAR"; box.addView(btn)
        btn.setOnClickListener{
            val user=u.text.toString(); val pass=p.text.toString()
            if((user=="admin" && pass=="1234") || (user=="empleado" && pass=="1234")) home(user=="admin")
            else Toast.makeText(this,"Usuario o contraseña incorrectos",Toast.LENGTH_SHORT).show()
        }
        setContentView(box)
    }
    fun home(admin:Boolean){
        val scroll=ScrollView(this); val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        box.addView(tv("🍓 PULPIX 2",30f)); box.addView(tv(if(admin)"Administrador" else "Empleado",20f))
        val items= listOf("💰 Capital inicial","💵 Ventas","💸 Gastos","📦 Inventario","🧾 Fiados","🏦 Caja","📊 Balance","📈 Gráficos","📋 Reportes","🍓 Productos","💾 Respaldo")
        for(x in items){ val b=Button(this); b.text=x; box.addView(b); b.setOnClickListener{ 
            if(x=="💰 Capital inicial" && admin) capital()
            else if(x=="💾 Respaldo") Toast.makeText(this,"Respaldo básico disponible en la siguiente versión",Toast.LENGTH_LONG).show()
            else Toast.makeText(this,"Módulo $x listo para configurar",Toast.LENGTH_SHORT).show()
        }}
        if(admin){ val b=Button(this); b.text="👥 Usuarios"; box.addView(b); b.setOnClickListener{users()} }
        scroll.addView(box); setContentView(scroll)
    }
    fun capital(){
        val e=EditText(this); e.hint="Ej. 300000"; e.inputType=2
        AlertDialog.Builder(this).setTitle("Capital inicial").setView(e).setMessage("Este valor inicia la caja y no se registra como venta.")
        .setPositiveButton("Guardar"){_,_-> prefs.edit().putLong("capital",e.text.toString().toLongOrNull()?:0).apply()
        }.setNegativeButton("Cancelar",null).show()
    }
    fun users(){ AlertDialog.Builder(this).setTitle("Usuarios de Pulpix 2")
        .setMessage("Administrador: admin / 1234\nEmpleado: empleado / 1234\n\nCambia estas credenciales antes de usar la app en producción.")
        .setPositiveButton("OK",null).show() }
}