plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android { namespace = "com.pulpix2"; compileSdk = 35
    defaultConfig { applicationId = "com.pulpix2"; minSdk = 24; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}
